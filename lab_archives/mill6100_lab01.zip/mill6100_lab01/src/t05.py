"""
------------------------------------------------------------------------
Lab 1, Task 5 - Movie_utilities#get_movie Testing
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-14
------------------------------------------------------------------------
"""
from Movie_utilities import get_movie

my_movie = get_movie()

print(my_movie)
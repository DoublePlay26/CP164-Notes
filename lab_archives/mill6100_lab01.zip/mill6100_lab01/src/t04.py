"""
------------------------------------------------------------------------
Lab 1, Task 4 - Movie_utilities#read_genres Testing
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-14
------------------------------------------------------------------------
"""
from Movie_utilities import read_genres

genres = read_genres()

print(genres)

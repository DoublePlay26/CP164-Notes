"""
------------------------------------------------------------------------
Assignment 1, Task 7 - Rotate Right
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-14
------------------------------------------------------------------------
"""
from functions import rotate_right

matrix = [[1,2,3],[4,5,6],[7,8,9]]

rotated = rotate_right(matrix)

print("Matrix: {}".format(matrix))
print("Rotated: {}".format(rotated))
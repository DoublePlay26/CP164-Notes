"""
------------------------------------------------------------------------
Assignment 1, Task 8 - Clean List
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-14
------------------------------------------------------------------------
"""
from functions import clean_list

my_list = [1, 2, 0, 1, 4, 1, 1, 2, 2, 5, 4, 3, 1, 3, 3, 4, 2, 4, 3, 1, 3, 0, 3, 0, 0]
clean_list(my_list)

print("Values: {}".format(my_list))
print("Cleaned: {}".format(my_list))
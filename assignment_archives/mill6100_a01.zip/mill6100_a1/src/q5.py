"""
------------------------------------------------------------------------
Assignment 1, Task 5 - Max Diff
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-14
------------------------------------------------------------------------
"""
from functions import max_diff

values = [1, 4, 100, -3]

md = max_diff(values)

print("Values: {}".format(values))
print("Max diff: {}".format(md))
"""
------------------------------------------------------------------------
Implementation of an Array-based Queue
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2019-01-21
------------------------------------------------------------------------
"""
from copy import deepcopy

class Queue():
    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty queue. Data is stored in a Python list.
        Use: queue = Queue()
        -------------------------------------------------------
        Returns:
            a new Queue object (Queue)
        -------------------------------------------------------
        """
        self._values = []
        
    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the Queue is empty.
        Use: b = q.is_empty()
        -------------------------------------------------------
        Returns:
            True if the Queue is empty, False otherwise
        -------------------------------------------------------
        """
        return
    
    def is_full(self):
        """
        -------------------------------------------------------
        Determines if the Queue is full.
        Use: b = q.is_empty()
        -------------------------------------------------------
        Returns:
            True if the Queue is full, False otherwise
        -------------------------------------------------------
        """
        return
    def peek(self):
        """
        -------------------------------------------------------
        Returns a copy of the value at the bottom of the Queue.
        Attempting to peek at an empty Queue throws an exception
        Use: value = q.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the bottom of the Queue
        -------------------------------------------------------
        """
        assert len(self._values) > 0, "Cannot peek an empty Queue"
        
        value = deepcopy(self._values[0])
        return value
    
    def insert(self, value):
        """
        -------------------------------------------------------
        Adds a copy of value to the rear of the queue.
        Use: queue.insert(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.append(deepcopy(value))
        return
    
    def __len__(self):
        """
        -------------------------------------------------------
        Returns the length of the queue.
        Use: n = len(queue)
        -------------------------------------------------------
        Returns:
            the number of values in queue.
        -------------------------------------------------------
        """
        return len(self._values)
    
    